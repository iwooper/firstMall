define({
  // Generic.
  OK: 'OK',
  CANCEL: 'Abbrechen',
  RESET: 'Zurücksetzen',

  // Menu.
  MENU_ON_SAVE: 'Automatische Präfixe beim Speichern',
  // MENU_ON_CHANGE: "Auto prefix when file is changed",
  MENU_SELECTION: 'Automatische Präfixe für die Auswahl',
  MENU_SETTINGS: 'Autoprefixer-Einstellungen...',

  // Settings dialog.
  SETTINGS_TITLE: 'Autoprefixer-Einstellungen',
  SETTINGS_VISUAL_CASCADE: 'Einrückungskaskade',
  SETTINGS_BROWSERS: 'Browser'
});
