define({
  // Generic.
  OK: 'Гаразд',
  CANCEL: 'Скасувати',
  RESET: 'Скинути',

  // Menu.
  MENU_ON_SAVE: 'Додавати префікси під час збереження',
  // MENU_ON_CHANGE: "Auto prefix when file is changed",
  MENU_SELECTION: 'Додавати префікси під час виділення',
  MENU_SETTINGS: 'Налаштувати Autoprefixer...',

  // Settings dialog.
  SETTINGS_TITLE: 'Параметри Autoprefixer',
  SETTINGS_VISUAL_CASCADE: 'Каскадні відступи',
  SETTINGS_BROWSERS: 'Браузери'
});
