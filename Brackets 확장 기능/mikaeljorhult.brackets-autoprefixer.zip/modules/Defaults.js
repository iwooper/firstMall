define(function () {
  'use strict';

  // Return object with default values.
  return {
    browsers: ['> 1%', 'last 2 versions', 'Firefox ESR']
  };
});
